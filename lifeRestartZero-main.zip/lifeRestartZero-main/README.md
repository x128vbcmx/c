#人生重开模拟器魔改版

#去掉开局只能选择3个的天赋   随你选几个

#开局天赋选择可以有50个备选项

#修改各项数值和游戏难度  更容易得到最完美结局

#在线试玩

#https://mypirlo.github.io/lifeRestartZero/view/index.html
